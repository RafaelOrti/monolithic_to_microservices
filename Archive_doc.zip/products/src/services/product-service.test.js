//which service it is
describe("ProductService", ()=> {
    //which function
    describe("CreateProduct", () => {
        //which Scenario we are testing
        test("validate user inputs", () => {});

        test("validate response", async () => {})
    })
})