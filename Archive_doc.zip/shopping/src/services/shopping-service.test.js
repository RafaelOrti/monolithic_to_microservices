//which service it is
describe("ShoppingService", ()=> {
    //which function
    describe("PlaceOrder", () => {
        //which Scenario we are testing
        test("validate user inputs", () => {});

        test("validate response", async () => {})
    })
})