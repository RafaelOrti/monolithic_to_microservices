//which service it is
describe("CustomerService", ()=> {
    //which function
    describe("SignIn", () => {
        //which Scenario we are testing
        test("validate user inputs", () => {});

        test("validate response", async () => {})
    })
})