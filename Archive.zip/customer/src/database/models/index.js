module.exports = {
    CustomerModel: require('./Customer'),
    AddressModel: require('./Address')
}