Convert monolithic nodejs repo to microservices
